const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const multer = require('multer');
const path = require('path');
const session = require('express-session');

const app = express();

// Configurazioni
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Configurazione express-session
app.use(session({
    secret: 'secretKey', // Cambia con una chiave più sicura
    resave: false,
    saveUninitialized: true
}));

// Configurazione per il salvataggio delle immagini
const storage = multer.diskStorage({
    destination: './public/uploads/',
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage: storage });

// Funzione per caricare i dati JSON
function loadData() {
    const users = JSON.parse(fs.readFileSync('./data/users.json', 'utf8'));
    const posts = JSON.parse(fs.readFileSync('./data/posts.json', 'utf8'));
    return { users, posts };
}

// Middleware per proteggere le pagine
function checkAuth(req, res, next) {
    if (!req.session.user) {
        return res.redirect('/login');
    }
    next();
}

// Home - Mostra i post (Passa anche lo stato dell'utente)
app.get('/', (req, res) => {
    const { posts } = loadData();
    const query = req.query.query || ''; // Aggiungi la query alla vista
    res.render('index', { posts, user: req.session.user || null, query }); // Passa "query" al template
});

// Search - Funzionalità di ricerca
app.get('/search', (req, res) => {
    const query = req.query.query || ''; // Otteniamo la query dalla barra di ricerca

    // Se la query non è vuota, eseguiamo la ricerca
    if (query) {
        const { posts } = loadData();
        // Cerchiamo nei titoli o nel contenuto dei post
        const filteredPosts = posts.filter(post => 
            post.title.toLowerCase().includes(query.toLowerCase()) ||
            post.content.toLowerCase().includes(query.toLowerCase())
        );
        res.render('index', { posts: filteredPosts, user: req.session.user || null, query });
    } else {
        // Se la query è vuota, mostriamo tutti i post
        const { posts } = loadData();
        res.render('index', { posts, user: req.session.user || null, query });
    }
});

// Login
app.get('/login', (req, res) => {
    res.render('login');
});

// Registrazione
app.get('/register', (req, res) => {
    res.render('register');
});

// Registrazione (POST)
app.post('/register', (req, res) => {
    const { username, password } = req.body;
    const { users } = loadData();
    
    if (users.find(user => user.username === username)) {
        return res.send('Username già esistente!');
    }

    users.push({ username, password });
    fs.writeFileSync('./data/users.json', JSON.stringify(users, null, 2));

    req.session.user = username; // Login automatico dopo registrazione
    res.redirect('/');
});

// Login (POST)
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const { users } = loadData();
    const user = users.find(u => u.username === username);

    if (!user || user.password !== password) {
        return res.send('Credenziali errate!');
    }

    req.session.user = username;
    res.redirect('/');
});

// Logout - Distrugge la sessione e reindirizza alla home
app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.send('Errore nel logout.');
        }
        res.redirect('/'); // Reindirizza alla home invece di login
    });
});

// Protegge la pagina di creazione del post: solo utenti loggati possono accedere
app.get('/create-post', (req, res) => {
    if (!req.session.user) {
        return res.redirect('/login'); // Reindirizza se non loggato
    }
    res.render('create-post', { user: req.session.user }); // Passa l'utente loggato
});

// Pubblica un annuncio
app.post('/create-post', upload.single('image'), (req, res) => {
    if (!req.session.user) {
        return res.redirect('/login'); // Impedisce a utenti non loggati di creare post
    }

    const { title, price, postContent } = req.body;
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : ''; // Percorso immagine
    const { posts } = loadData();

    const newPost = { 
        username: req.session.user, // Usa l'utente della sessione
        title, 
        price, 
        content: postContent, 
        imageUrl, 
        date: new Date().toLocaleString() 
    };

    posts.push(newPost);
    fs.writeFileSync('./data/posts.json', JSON.stringify(posts, null, 2));
    res.redirect('/');
});

// Avvio del server
app.listen(3000, () => {
    console.log('Server in esecuzione su http://localhost:3000');
});
