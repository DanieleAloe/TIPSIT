const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const multer = require('multer');
const path = require('path');
const session = require('express-session');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Configurazioni
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.use(session({
    secret: 'secretKey',
    resave: false,
    saveUninitialized: true
}));

// Upload immagini
const storage = multer.diskStorage({
    destination: './public/uploads/',
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage: storage });

// Load JSON
function loadData() {
    const users = JSON.parse(fs.readFileSync('./data/users.json', 'utf8'));
    const posts = JSON.parse(fs.readFileSync('./data/posts.json', 'utf8'));
    return { users, posts };
}

// SOCKET UTENTI ONLINE
let utentiOnline = 0;

io.on('connection', (socket) => {
    utentiOnline++;
    io.emit('onlineCount', utentiOnline);

    socket.on('disconnect', () => {
        utentiOnline--;
        io.emit('onlineCount', utentiOnline);
    });
});

// HOME
app.get('/', (req, res) => {
    const { posts } = loadData();
    const query = req.query.query || '';
    res.render('index', { posts, user: req.session.user || null, query });
});

// SEARCH
app.get('/search', (req, res) => {
    const query = req.query.query || '';
    const { posts } = loadData();

    const filtered = query
        ? posts.filter(p =>
            p.title.toLowerCase().includes(query.toLowerCase()) ||
            p.content.toLowerCase().includes(query.toLowerCase())
        )
        : posts;

    res.render('index', { posts: filtered, user: req.session.user || null, query });
});

// LOGIN
app.get('/login', (req, res) => res.render('login'));
app.get('/register', (req, res) => res.render('register'));

// REGISTER
app.post('/register', (req, res) => {
    const { username, password } = req.body;
    const { users } = loadData();

    if (users.find(u => u.username === username)) {
        return res.send('Username già esistente!');
    }

    users.push({ username, password });
    fs.writeFileSync('./data/users.json', JSON.stringify(users, null, 2));

    req.session.user = username;
    res.redirect('/');
});

// LOGIN POST
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const { users } = loadData();

    const user = users.find(u => u.username === username);

    if (!user || user.password !== password) {
        return res.send('Credenziali errate!');
    }

    req.session.user = username;
    res.redirect('/');
});

// LOGOUT
app.get('/logout', (req, res) => {
    req.session.destroy(() => res.redirect('/'));
});

// CREATE POST PAGE
app.get('/create-post', (req, res) => {
    if (!req.session.user) return res.redirect('/login');
    res.render('create-post', { user: req.session.user });
});

// CREATE POST
app.post('/create-post', upload.single('image'), (req, res) => {
    if (!req.session.user) return res.redirect('/login');

    const { title, price, postContent, size, condition } = req.body;
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : '';
    const { posts } = loadData();

    const newPost = {
        username: req.session.user,
        title,
        price,
        content: postContent,
        size,
        condition,
        imageUrl,
        date: new Date().toLocaleString()
    };

    posts.push(newPost);
    fs.writeFileSync('./data/posts.json', JSON.stringify(posts, null, 2));

    res.redirect('/');
});

// SERVER START
server.listen(3000, () => {
    console.log('Server attivo su http://localhost:3000');
});