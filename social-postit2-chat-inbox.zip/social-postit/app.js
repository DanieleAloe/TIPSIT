const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const multer = require('multer');
const path = require('path');
const session = require('express-session');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Configurazioni
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

const sessionMiddleware = session({
    secret: 'secretKey',
    resave: false,
    saveUninitialized: false
});

app.use(sessionMiddleware);
io.engine.use(sessionMiddleware);

// Upload immagini
const storage = multer.diskStorage({
    destination: './public/uploads/',
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage: storage });

const USERS_FILE = './data/users.json';
const POSTS_FILE = './data/posts.json';
const CHATS_FILE = './data/chats.json';

function readJson(file, fallback) {
    if (!fs.existsSync(file)) return fallback;
    return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function writeJson(file, data) {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// Load JSON
function loadData() {
    const users = readJson(USERS_FILE, []);
    const posts = readJson(POSTS_FILE, []);
    const chats = readJson(CHATS_FILE, []);
    return { users, posts, chats };
}

function requireLogin(req, res, next) {
    if (!req.session.user) {
        return res.redirect('/login?redirect=' + encodeURIComponent(req.originalUrl));
    }
    next();
}

function getPostById(postId) {
    const { posts } = loadData();
    return posts.find(p => p.id === postId);
}

function getChatRoomId(postId, seller, buyer) {
    return `${postId}__${seller}__${buyer}`;
}

function getOrCreateChat(postId, seller, buyer) {
    const chats = readJson(CHATS_FILE, []);
    const roomId = getChatRoomId(postId, seller, buyer);
    let chat = chats.find(c => c.roomId === roomId);

    if (!chat) {
        chat = {
            roomId,
            postId,
            seller,
            buyer,
            messages: [],
            createdAt: new Date().toISOString()
        };
        chats.push(chat);
        writeJson(CHATS_FILE, chats);
    }

    return chat;
}

function userCanAccessChat(username, chat) {
    return username === chat.seller || username === chat.buyer;
}

// SOCKET UTENTI ONLINE + CHAT REALTIME
let utentiOnline = 0;

io.on('connection', (socket) => {
    utentiOnline++;
    io.emit('onlineCount', utentiOnline);

    socket.on('joinChat', ({ roomId }) => {
        const username = socket.request.session?.user;
        if (!username) return;

        const { chats } = loadData();
        const chat = chats.find(c => c.roomId === roomId);

        // Sicurezza: entra nella stanza solo venditore o acquirente.
        if (!chat || !userCanAccessChat(username, chat)) return;

        socket.join(roomId);
    });

    socket.on('sendMessage', ({ roomId, text }) => {
        const username = socket.request.session?.user;
        if (!username || !text || !text.trim()) return;

        const chats = readJson(CHATS_FILE, []);
        const chat = chats.find(c => c.roomId === roomId);

        // Sicurezza: solo i 2 utenti autorizzati possono inviare messaggi.
        if (!chat || !userCanAccessChat(username, chat)) return;

        const message = {
            sender: username,
            text: text.trim(),
            date: new Date().toLocaleString(),
            isoDate: new Date().toISOString()
        };

        chat.messages.push(message);
        writeJson(CHATS_FILE, chats);

        io.to(roomId).emit('newMessage', message);
    });

    socket.on('disconnect', () => {
        utentiOnline--;
        io.emit('onlineCount', utentiOnline);
    });
});

// HOME
app.get('/', (req, res) => {
    const { posts } = loadData();
    const query = req.query.query || '';
    res.render('index', { posts, user: req.session.user || null, query });
});

// SEARCH
app.get('/search', (req, res) => {
    const query = req.query.query || '';
    const { posts } = loadData();

    const filtered = query
        ? posts.filter(p =>
            p.title.toLowerCase().includes(query.toLowerCase()) ||
            p.content.toLowerCase().includes(query.toLowerCase())
        )
        : posts;

    res.render('index', { posts: filtered, user: req.session.user || null, query });
});

// LOGIN
app.get('/login', (req, res) => res.render('login', { redirect: req.query.redirect || '' }));
app.get('/register', (req, res) => res.render('register'));

// REGISTER
app.post('/register', (req, res) => {
    const { username, password } = req.body;
    const { users } = loadData();

    if (users.find(u => u.username === username)) {
        return res.send('Username già esistente!');
    }

    users.push({ username, password });
    writeJson(USERS_FILE, users);

    req.session.user = username;
    res.redirect('/');
});

// LOGIN POST
app.post('/login', (req, res) => {
    const { username, password, redirect } = req.body;
    const { users } = loadData();

    const user = users.find(u => u.username === username);

    if (!user || user.password !== password) {
        return res.send('Credenziali errate!');
    }

    req.session.user = username;
    res.redirect(redirect || '/');
});

// LOGOUT
app.get('/logout', (req, res) => {
    req.session.destroy(() => res.redirect('/'));
});

// CREATE POST PAGE
app.get('/create-post', requireLogin, (req, res) => {
    res.render('create-post', { user: req.session.user });
});

// CREATE POST
app.post('/create-post', requireLogin, upload.single('image'), (req, res) => {
    const { title, price, postContent, size, condition } = req.body;
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : '';
    const { posts } = loadData();

    const newPost = {
        id: Date.now().toString(),
        username: req.session.user,
        title,
        price,
        content: postContent,
        size,
        condition,
        imageUrl,
        date: new Date().toLocaleString(),
            isoDate: new Date().toISOString()
    };

    posts.push(newPost);
    writeJson(POSTS_FILE, posts);

    res.redirect('/');
});


// LISTA CHAT DELL'UTENTE LOGGATO (INBOX)
app.get('/chats', requireLogin, (req, res) => {
    const { chats, posts } = loadData();
    const username = req.session.user;

    const userChats = chats
        .filter(chat => userCanAccessChat(username, chat))
        .map(chat => {
            const post = posts.find(p => p.id === chat.postId);
            const lastMessage = chat.messages && chat.messages.length > 0
                ? chat.messages[chat.messages.length - 1]
                : null;

            return {
                ...chat,
                post,
                otherUser: username === chat.seller ? chat.buyer : chat.seller,
                lastMessage
            };
        })
        .sort((a, b) => {
            const dateA = a.lastMessage ? new Date(a.lastMessage.isoDate || a.createdAt) : new Date(a.createdAt);
            const dateB = b.lastMessage ? new Date(b.lastMessage.isoDate || b.createdAt) : new Date(b.createdAt);
            return dateB - dateA;
        });

    res.render('chats', {
        user: username,
        chats: userChats
    });
});

// CHAT PRIVATA TRA ACQUIRENTE E VENDITORE
app.get('/chat/:postId', requireLogin, (req, res) => {
    const post = getPostById(req.params.postId);
    if (!post) return res.status(404).send('Post non trovato');

    if (post.username === req.session.user) {
        return res.send('Non puoi contattare te stesso per un tuo annuncio.');
    }

    const chat = getOrCreateChat(post.id, post.username, req.session.user);

    res.render('chat', {
        user: req.session.user,
        post,
        chat,
        otherUser: post.username
    });
});

// Permette anche al venditore di riaprire una chat già esistente.
app.get('/chat-room/:roomId', requireLogin, (req, res) => {
    const { chats, posts } = loadData();
    const chat = chats.find(c => c.roomId === req.params.roomId);

    if (!chat || !userCanAccessChat(req.session.user, chat)) {
        return res.status(403).send('Chat non autorizzata');
    }

    const post = posts.find(p => p.id === chat.postId);
    res.render('chat', {
        user: req.session.user,
        post,
        chat,
        otherUser: req.session.user === chat.seller ? chat.buyer : chat.seller
    });
});

// SERVER START
server.listen(3000, () => {
    console.log('Server attivo su http://localhost:3000');
});
